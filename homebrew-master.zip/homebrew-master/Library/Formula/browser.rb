require 'formula'

class Browser < GithubGistFormula
  url 'https://gist.github.com/raw/318247/bcbcf6c5fb730b4f508c633cce56ba17828825c8/browser'
  homepage 'https://gist.github.com/318247/'
  sha1 '3474d81ef6eaaf13554fd6aa03e5227c4c72f1bb'
end
